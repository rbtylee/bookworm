# Add sbin dirs to PATH
export PATH=$PATH:/usr/local/sbin:/usr/sbin:/sbin
